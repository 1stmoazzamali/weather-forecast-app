const String OPENWEATHER_API_KEY = "f6204d103d5cea526d9b62c5ebdd1af0";
const String BASE_URL = "https://api.openweathermap.org/data/2.5";
const String ICON_URL = "https://openweathermap.org/img/wn/";
