import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../models/weather_model.dart';
import '../services/weather_services.dart';

class WeatherProvider extends ChangeNotifier {
  bool isLoading = false;
  WeatherModel? weather;
  List<WeatherModel> forecast = [];

  final WeatherService _weatherService = WeatherService();

  Future<void> fetchWeatherByCity(String city) async {
    isLoading = true;
    notifyListeners();

    weather = await _weatherService.fetchWeatherByCity(city);
    forecast = await _weatherService.fetchForecastByCity(city);

    isLoading = false;
    notifyListeners();
  }

  Future<void> fetchWeatherByLocation() async {
    isLoading = true;
    notifyListeners();

    try {
      Position position = await _determinePosition();
      weather = await _weatherService.fetchWeatherByLocation(
        position.latitude,
        position.longitude,
      );

      if (weather != null) {
        forecast = await _weatherService.fetchForecastByCity(weather!.cityName);
      }
    } catch (_) {
      weather = null;
    }

    isLoading = false;
    notifyListeners();
  }

  Future<Position> _determinePosition() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw Exception('Location services are disabled.');
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw Exception('Location permissions are denied.');
      }
    }
    if (permission == LocationPermission.deniedForever) {
      throw Exception(
        'Location permissions are permanently denied, cannot request.',
      );
    }

    return await Geolocator.getCurrentPosition();
  }
}
