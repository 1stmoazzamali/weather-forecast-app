import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import '../providers/weather_provider.dart';
import 'forecast_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    Provider.of<WeatherProvider>(
      context,
      listen: false,
    ).fetchWeatherByLocation();
  }

  String getAnimationForWeather(String condition) {
    if (condition.contains('rain')) return 'assets/animations/rain.json';
    if (condition.contains('cloud')) return 'assets/animations/cloudy.json';
    if (condition.contains('clear')) return 'assets/animations/sunny.json';
    return 'assets/animations/sunny.json';
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<WeatherProvider>(context);
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF4facfe), Color(0xFF00f2fe)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: SingleChildScrollView(
                physics:
                    bottomInset > 0
                        ? const BouncingScrollPhysics()
                        : const NeverScrollableScrollPhysics(),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    minHeight:
                        MediaQuery.of(context).size.height -
                        MediaQuery.of(context).padding.top -
                        MediaQuery.of(context).padding.bottom,
                  ),
                  child: IntrinsicHeight(
                    child: Column(
                      children: [
                        // Search bar
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          child: TextField(
                            controller: _controller,
                            style: const TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              hintText: 'Search city...',
                              hintStyle: const TextStyle(color: Colors.white70),
                              border: InputBorder.none,
                              prefixIcon: const Icon(
                                Icons.search,
                                color: Colors.white,
                              ),
                              suffixIcon: IconButton(
                                icon: const Icon(
                                  Icons.my_location,
                                  color: Colors.white,
                                ),
                                onPressed: () {
                                  provider.fetchWeatherByLocation();
                                },
                              ),
                            ),
                            onSubmitted: (value) {
                              if (value.isNotEmpty) {
                                provider.fetchWeatherByCity(value);
                              }
                            },
                          ),
                        ),
                        const SizedBox(height: 20),

                        // Weather display
                        Expanded(
                          child: Center(
                            child:
                                provider.isLoading
                                    ? const CircularProgressIndicator(
                                      color: Colors.white,
                                    )
                                    : provider.weather == null
                                    ? const Text(
                                      'No weather data',
                                      style: TextStyle(color: Colors.white),
                                    )
                                    : Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Lottie.asset(
                                          getAnimationForWeather(
                                            provider.weather!.description
                                                .toLowerCase(),
                                          ),
                                          height: 180,
                                        ),
                                        Text(
                                          provider.weather!.cityName,
                                          style: GoogleFonts.poppins(
                                            color: Colors.white,
                                            fontSize: 32,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        Text(
                                          '${provider.weather!.temperature.toStringAsFixed(1)}°C',
                                          style: GoogleFonts.poppins(
                                            color: Colors.white,
                                            fontSize: 60,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        Text(
                                          provider.weather!.description,
                                          style: GoogleFonts.poppins(
                                            color: Colors.white70,
                                            fontSize: 20,
                                          ),
                                        ),
                                        const SizedBox(height: 20),

                                        // Glassmorphism card
                                        Container(
                                          padding: const EdgeInsets.all(16),
                                          decoration: BoxDecoration(
                                            color: Colors.white.withOpacity(
                                              0.2,
                                            ),
                                            borderRadius: BorderRadius.circular(
                                              20,
                                            ),
                                            border: Border.all(
                                              color: Colors.white.withOpacity(
                                                0.3,
                                              ),
                                              width: 1,
                                            ),
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceAround,
                                            children: [
                                              _buildWeatherInfo(
                                                Icons.wind_power,
                                                '${provider.weather!.wind} m/s',
                                              ),
                                              _buildWeatherInfo(
                                                Icons.water_drop,
                                                '${provider.weather!.humidity}%',
                                              ),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(height: 20),
                                        ElevatedButton(
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.white
                                                .withOpacity(0.2),
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                            ),
                                          ),
                                          onPressed: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder:
                                                    (_) =>
                                                        const ForecastScreen(),
                                              ),
                                            );
                                          },
                                          child: const Text(
                                            'View Forecast',
                                            style: TextStyle(
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildWeatherInfo(IconData icon, String value) {
    return Column(
      children: [
        Icon(icon, color: Colors.white, size: 28),
        const SizedBox(height: 5),
        Text(
          value,
          style: GoogleFonts.poppins(color: Colors.white, fontSize: 16),
        ),
      ],
    );
  }
}
