import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/weather_model.dart';

class WeatherService {
  final String _apiKey =
      'f6204d103d5cea526d9b62c5ebdd1af0'; // Replace with your key

  Future<WeatherModel?> fetchWeatherByCity(String city) async {
    final url =
        'https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$_apiKey&units=metric';
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return WeatherModel.fromJson(data);
      }
    } catch (_) {}
    return null;
  }

  Future<WeatherModel?> fetchWeatherByLocation(double lat, double lon) async {
    final url =
        'https://api.openweathermap.org/data/2.5/weather?lat=$lat&lon=$lon&appid=$_apiKey&units=metric';
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return WeatherModel.fromJson(data);
      }
    } catch (_) {}
    return null;
  }

  Future<List<WeatherModel>> fetchForecastByCity(String city) async {
    final url =
        'https://api.openweathermap.org/data/2.5/forecast?q=$city&appid=$_apiKey&units=metric';
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return (data['list'] as List)
            .map(
              (item) => WeatherModel(
                cityName: data['city']['name'],
                temperature: (item['main']['temp'] as num).toDouble(),
                description: item['weather'][0]['description'],
                wind: (item['wind']['speed'] as num).toDouble(),
                humidity: item['main']['humidity'],
                mainCondition: item['weather'][0]['main'],
                date: DateTime.tryParse(item['dt_txt']),
              ),
            )
            .toList();
      }
    } catch (_) {}
    return [];
  }
}
