class WeatherModel {
  final String cityName;
  final double temperature;
  final String description;
  final double wind;
  final int humidity;
  final String mainCondition;
  final DateTime? date; // Optional for forecast items

  WeatherModel({
    required this.cityName,
    required this.temperature,
    required this.description,
    required this.wind,
    required this.humidity,
    required this.mainCondition,
    this.date,
  });

  factory WeatherModel.fromJson(Map<String, dynamic> json) {
    return WeatherModel(
      cityName: json['name'] ?? '', // Empty for forecast entries
      temperature: (json['main']['temp'] as num).toDouble(),
      description: json['weather'][0]['description'],
      wind: (json['wind']['speed'] as num).toDouble(),
      humidity: json['main']['humidity'],
      mainCondition: json['weather'][0]['main'],
      date: json['dt_txt'] != null ? DateTime.tryParse(json['dt_txt']) : null,
    );
  }
}
